module.exports = {
  testEnvironment: 'jsdom',
};
